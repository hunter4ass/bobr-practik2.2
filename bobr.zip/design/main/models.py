from django.db import models

# Create your models here.
class Request:
    pass